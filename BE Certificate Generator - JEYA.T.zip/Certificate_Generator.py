import pandas as pd
from PIL import Image, ImageDraw, ImageFont
# import pdb;pdb.set_trace()
data = pd.read_excel(r'C:\Users\ELCOT\Desktop\cert\Book1.xlsx')
name = data["Name"].tolist()
gender = data["Gender"].tolist()
cert_no = data["Certificate Number"].tolist()
mentor = data["Mentor Name"].tolist()
project_man = data["Project Manger"].tolist()

for i in range(len(name)):
    img = Image.open(r'C:\Users\ELCOT\Desktop\cert\certificate1.jpg')
    d = ImageDraw.Draw(img)
    text_color = (0, 137, 209)
    font = ImageFont.truetype("arial.ttf", 25)
    
    d.text((767, 369), name[i], fill = text_color, font = font)
    d.text((680, 370), gender[i], fill = text_color, font = font)
    d.text((783, 183), str(cert_no[i]), fill = text_color, font = font)
    d.text((99, 564), mentor[i], fill = text_color, font = font)
    d.text((702, 564), project_man[i], fill = text_color, font = font)
    
    img.save("certificate1_" + name[i] + ".jpg")

print("Certificate Generation is DONE\n THANKYOU !!!\n Please Print Your Certificate !!!")